Rhythms of the Body
-------------------

This project was built during my final year of BSc Games Programming
at Goldsmiths, University of London. It was written with the intention
of forcing myself to construct various components of a video game that
I might otherwise ignore. It is essentially a technical demo, and the
final product is more of an art piece than a fully fleshed out video
game. A macOS build is provided in the 'bin' directory.

I built the following components of the software myself:
- 2D software renderer.
    - Bitmap rendering.
    - Frame-based animation system.
    - Text rendering.
- Audio mixer.
- Simple memory allocator (used throughout the programme).
- File loading, including reading file headers.
- 'Scene' management; divides up game-play code.

The project was written in C so that I could not lean on an extensive
standard library. I would like to emphasise that I am very comfortable
programming with C++. I used SDL2 as a platform layer for lack of
time, as I had to write a 40 page dissertation alongside the project!

There are plenty of peculiar design decisions made which are
explained in the accompanying dissertation, but I do not expect you to
read it! Just ask me directly if there is something you would like
explaining - every decision was heavily thought out.

- Ben
